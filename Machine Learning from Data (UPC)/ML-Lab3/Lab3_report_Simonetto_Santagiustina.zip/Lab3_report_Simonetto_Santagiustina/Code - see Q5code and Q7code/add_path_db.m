% Add the path to the ZIP and microarray db
path(path,[cd,filesep,'zipcode']);
path(path,[cd,filesep,'microarray']);
